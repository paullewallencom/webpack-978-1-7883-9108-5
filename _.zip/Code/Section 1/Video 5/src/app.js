console.log("Hello world... with devserver");

document.getElementById('main').innerHTML += '<br /> <p>Our javascript content!</p>'
